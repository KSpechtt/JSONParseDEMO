package com.example.jsonparser;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private TextView mTextViewResult;
    private RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Getting our textview and button.
        mTextViewResult = findViewById(R.id.text_view_result);
        Button buttonParse = findViewById(R.id.button_parse);

        //Volley is an HTTP library that makes networking for Android apps easier and most importantly, faster.
        mQueue = Volley.newRequestQueue(this);

        buttonParse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                jsonParse();
            }
        });
    }

    private void jsonParse() {
        String url = "https://statsapi.web.nhl.com/api/v1/teams/23?expand=team.roster";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                //This has to be wrapped in a try catch or it produces an error.
                try {
                    //The name of the JSON array
                    JSONArray jsonArray = response.getJSONArray("teams");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        //Creating our JSONObject of team
                        JSONObject team = jsonArray.getJSONObject(i);

                        //Getting our team name and team id's
                        String teamName = team.getString("name");
                        int teamID = team.getInt("id");

                        //Creating a new JSONObject to retrieve the nested values
                        JSONObject venue = team.getJSONObject("venue");
                        //getting the nested values inside the teams array
                        String venueName = venue.getString("name");
                        String cityName = venue.getString("city");

                        //Appending the information we've gathered so far to our textview.
                        mTextViewResult.append("Team Name: " + teamName + "\n" +
                                "Team ID: " + String.valueOf(teamID) + "\n" +
                                "Venue Name: " + venueName + "\n" + "City Name: " + cityName + "\n\n" + "Roster" + "\n\n");

                        //Creating another JSON Object to retrieve roster information
                        JSONObject roster = team.getJSONObject("roster");
                        //Using our new JSON Object to get a new array that contains all the roster information for teams
                        JSONArray realRoster = roster.getJSONArray("roster");

                        //Looping through our nested array in our JSON url to get the roster information.
                        for (int j = 0; j < realRoster.length(); j++) {
                            //Creating our players json Object and setting it to the index of J
                            JSONObject players = realRoster.getJSONObject(j);
                            //Creating our person object and retrieving the fullname of said object
                            JSONObject person = players.getJSONObject("person");
                            String fullName = person.getString("fullName");
                            //Appending our players name to our textview
                            mTextViewResult.append(fullName + "\n");

                        }


                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);
    }
}

